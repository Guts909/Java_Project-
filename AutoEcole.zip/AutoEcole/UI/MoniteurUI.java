package AutoEcole.UI;

import AutoEcole.Controller.MoniteurController;
import AutoEcole.Entities.Moniteur;

import java.util.Scanner;

public class MoniteurUI {

    private final MoniteurController controller = new MoniteurController();
    private final Scanner sc = new Scanner(System.in);

    public void afficherMenu() {
        int choix;

        do {
            System.out.println("\n===== MENU MONITEURS =====");
            System.out.println("1. Ajouter un moniteur");
            System.out.println("2. Changer disponibilité");
            System.out.println("3. Ajouter heures travaillées");
            System.out.println("4. Afficher tous les moniteurs");
            System.out.println("0. Retour");
            System.out.print("Votre choix : ");

            choix = sc.nextInt();
            sc.nextLine(); // vider buffer

            switch (choix) {
                case 1 -> ajouterMoniteur();
                case 2 -> changerDisponibilite();
                case 3 -> ajouterHeures();
                case 4 -> afficherTous();
            }

        } while (choix != 0);
    }

    private void ajouterMoniteur() {
        System.out.print("Nom du moniteur : ");
        String nom = sc.nextLine();

        System.out.print("Salaire horaire : ");
        double salaire = sc.nextDouble();

        controller.ajouter(new Moniteur(nom, salaire));
        System.out.println("Moniteur ajouté avec succès !");
    }

    private void changerDisponibilite() {
        System.out.print("Nom du moniteur : ");
        String nom = sc.nextLine();

        Moniteur m = controller.chercher(nom);
        if (m == null) {
            System.out.println("Moniteur introuvable !");
            return;
        }

        m.setDisponible(!m.isDisponible());
        controller.mettreAJour(m);

        System.out.println("Disponibilité mise à jour !");
    }

    private void ajouterHeures() {
        System.out.print("Nom du moniteur : ");
        String nom = sc.nextLine();

        Moniteur m = controller.chercher(nom);
        if (m == null) {
            System.out.println("Moniteur introuvable !");
            return;
        }

        System.out.print("Heures à ajouter : ");
        double heures = sc.nextDouble();

        m.ajouterHeures(heures);
        controller.mettreAJour(m);

        System.out.println("Heures ajoutées !");
    }

    private void afficherTous() {
        controller.tout().forEach(System.out::println);
    }
}

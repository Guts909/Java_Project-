package AutoEcole.UI;

import AutoEcole.Controller.SeanceController;
import AutoEcole.Entities.Seance;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class SeanceUI {
    private final SeanceController controller = new SeanceController();
    private final Scanner scanner = new Scanner(System.in);

    public void afficherMenuSeance() {
        int choix;
        do {
            System.out.println("\n=== GESTION DES SEANCES ===");
            System.out.println("1. Ajouter une séance");
            System.out.println("2. Supprimer une séance");
            System.out.println("3. Afficher toutes les séances");
            System.out.println("4. Rechercher une séance");
            System.out.println("5. Mettre à jour une séance");
            System.out.println("0. Retour au menu principal");
            System.out.print("Choix : ");
            choix = scanner.nextInt();
            scanner.nextLine();

            switch (choix) {
                case 1 -> ajouterSeance();
                case 2 -> supprimerSeance();
                case 3 -> afficherToutes();
                case 4 -> rechercherSeance();
                case 5 -> mettreAJourSeance();
                case 0 -> System.out.println("👋 Retour au menu principal...");
                default -> System.out.println("❌ Choix invalide !");
            }
        } while (choix != 0);
    }

    private void ajouterSeance() {
        System.out.print("Numéro de séance : ");
        int numero = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Date et heure (jj/MM/aaaa HH:mm) : ");
        String dateHeureStr = scanner.nextLine();
        LocalDateTime dateHeure = LocalDateTime.parse(dateHeureStr, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));

        System.out.print("Prix : ");
        double prix = scanner.nextDouble();
        scanner.nextLine();

        Seance s = new Seance(numero, dateHeure, null, prix);
        controller.ajouterSeance(s);
        System.out.println("✅ Séance ajoutée avec succès !");
    }

    private void supprimerSeance() {
        System.out.print("Numéro de la séance à supprimer : ");
        int numero = scanner.nextInt();
        scanner.nextLine();
        controller.supprimerSeance(numero);
        System.out.println("🗑️ Suppression effectuée (si existant).");
    }

    private void afficherToutes() {
        ArrayList<Seance> seances = controller.getToutes();
        if (seances.isEmpty()) {
            System.out.println("❌ Aucune séance disponible.");
        } else {
            System.out.println("\n=== Liste des séances ===");
            seances.forEach(System.out::println);
        }
    }

    private void rechercherSeance() {
        System.out.print("Numéro de la séance à rechercher : ");
        int numero = scanner.nextInt();
        scanner.nextLine();
        Seance s = controller.rechercherSeance(numero);
        if (s != null) {
            System.out.println("✅ Séance trouvée : " + s);
        } else {
            System.out.println("❌ Aucune séance trouvée.");
        }
    }

    private void mettreAJourSeance() {
        System.out.print("Numéro de la séance à mettre à jour : ");
        int numero = scanner.nextInt();
        scanner.nextLine();

        Seance s = controller.rechercherSeance(numero);
        if (s != null) {
            System.out.println("Séance actuelle : " + s);

            System.out.print("Nouvelle date et heure (jj/MM/aaaa HH:mm, vide pour garder) : ");
            String dateHeureStr = scanner.nextLine();
            if (!dateHeureStr.isEmpty()) {
                LocalDateTime dateHeure = LocalDateTime.parse(dateHeureStr, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
                s.setDateHeure(dateHeure);
            }

            System.out.print("Nouveau prix (laisser vide pour garder) : ");
            String prixStr = scanner.nextLine();
            if (!prixStr.isEmpty()) {
                double prix = Double.parseDouble(prixStr);
                s.setPrix(prix);
            }

            controller.mettreAJourSeance(s);
            System.out.println("✅ Séance mise à jour avec succès !");
        } else {
            System.out.println("❌ Séance introuvable !");
        }
    }
}

package AutoEcole.UI;

import java.util.Scanner;
import AutoEcole.Controller.CandidatController;
import AutoEcole.Entities.Candidat;

public class CandidatUI {
    private final CandidatController controller = new CandidatController();
    private final Scanner scanner = new Scanner(System.in);

    public void afficherMenuCandidat() {
        int choix;
        do {
            System.out.println("\n=== GESTION DES CANDIDATS ===");
            System.out.println("1. Ajouter un candidat");
            System.out.println("2. Supprimer un candidat");
            System.out.println("3. Rechercher un candidat");
            System.out.println("4. Afficher tous les candidats");
            System.out.println("5. Mettre à jour un candidat"); // ✏️ new option
            System.out.println("0. Quitter");
            System.out.print("Choix : ");
            choix = scanner.nextInt();
            scanner.nextLine();

            switch (choix) {
                case 1 -> ajouterCandidat();
                case 2 -> supprimerCandidat();
                case 3 -> rechercherCandidat();
                case 4 -> controller.afficherTous();
                case 5 -> mettreAJourCandidat(); // ✏️ new case
                case 0 -> System.out.println("👋 Retour au menu principal...");
                default -> System.out.println("❌ Choix invalide !");
            }

        } while (choix != 0);
    }

    private void ajouterCandidat() {
        System.out.print("CIN : ");
        String cin = scanner.nextLine();
        System.out.print("Nom : ");
        String nom = scanner.nextLine();
        System.out.print("Prénom : ");
        String prenom = scanner.nextLine();
        System.out.print("Catégorie de permis : ");
        String cat = scanner.nextLine();

        Candidat c = new Candidat(cin, nom, prenom, cat);
        controller.ajouterCandidat(c);
        System.out.println("✅ Candidat ajouté avec succès !");
    }

    private void supprimerCandidat() {
        System.out.print("CIN du candidat à supprimer : ");
        String cin = scanner.nextLine();
        controller.supprimerCandidat(cin);
        System.out.println("🗑️ Suppression effectuée (si existant).");
    }

    private void rechercherCandidat() {
        System.out.print("CIN du candidat à rechercher : ");
        String cin = scanner.nextLine();
        Candidat c = controller.rechercherCandidat(cin);
        if (c != null)
            System.out.println("✅ " + c);
        else
            System.out.println("❌ Aucun candidat trouvé.");
    }

    // ✏️ New method: update candidate
    private void mettreAJourCandidat() {
        System.out.print("CIN du candidat à mettre à jour : ");
        String cin = scanner.nextLine();
        Candidat c = controller.rechercherCandidat(cin);

        if (c != null) {
            System.out.println("Candidat trouvé : " + c);

            System.out.print("Nouveau nom (laisser vide pour garder l'ancien) : ");
            String nom = scanner.nextLine();
            if (!nom.isEmpty()) c.setNom(nom);

            System.out.print("Nouveau prénom (laisser vide pour garder l'ancien) : ");
            String prenom = scanner.nextLine();
            if (!prenom.isEmpty()) c.setPrenom(prenom);

            System.out.print("Nouvelle catégorie de permis (laisser vide pour garder l'ancienne) : ");
            String cat = scanner.nextLine();
            if (!cat.isEmpty()) c.setCategoriePermis(cat);

            // Save changes via controller
            controller.mettreAJourCandidat(c);
            System.out.println("✅ Candidat mis à jour avec succès !");
        } else {
            System.out.println("❌ Aucun candidat trouvé avec ce CIN.");
        }
    }
}

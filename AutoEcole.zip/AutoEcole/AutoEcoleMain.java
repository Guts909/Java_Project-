package AutoEcole;

import AutoEcole.UI.CandidatUI;
import AutoEcole.UI.SeanceUI;
import java.util.Scanner; // si tu l’as déjà créé

public class AutoEcoleMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CandidatUI candidatUI = new CandidatUI();
        SeanceUI seanceUI = new SeanceUI();
        // MoniteurUI moniteurUI = new MoniteurUI(); // optionnel

        int choix;
        do {
            System.out.println("\n=== MENU PRINCIPAL AUTO-ECOLE ===");
            System.out.println("1. Gestion des candidats");
            System.out.println("2. Gestion des séances");
            System.out.println("3. Gestion des moniteurs");
            System.out.println("0. Quitter");
            System.out.print("Choix : ");
            choix = scanner.nextInt();
            scanner.nextLine();

            switch (choix) {
                case 1 -> candidatUI.afficherMenuCandidat();
                case 2 -> seanceUI.afficherMenuSeance();
                case 3 -> System.out.println("👉 MoniteurUI pas encore implémenté !");
                case 0 -> System.out.println("👋 Au revoir !");
                default -> System.out.println("❌ Choix invalide !");
            }
        } while (choix != 0);

        scanner.close();
    }
}

package AutoEcole.Entities;
import java.util.ArrayList;


public class Candidat {
    private String cin;
    private String nom;
    private String prenom;
    private String categoriePermis;
    private double totalPaye;
    private double resteAPayer;
    private ArrayList<Seance> seances;


    public Candidat(String cin, String nom, String prenom, String categoriePermis) {
        this.cin = cin;
        this.nom = nom;
        this.prenom = prenom;
        this.categoriePermis = categoriePermis;
        this.totalPaye = 0;
        this.resteAPayer = 0;
        this.seances = new ArrayList<>();
    }

     // Getters & setters
    public String getCin() {
        return cin; 
    }
    public String getNom() {
        
        return nom; 
    }
    public String getPrenom() {
        return prenom; 
    }
    public String getCategoriePermis() {
        return categoriePermis; 
    }
    public double getTotalPaye() {
        return totalPaye; 
    }
    public double getResteAPayer() {
        return resteAPayer; 
    }
    public ArrayList<Seance> getSeances() {
        return seances; 
    }

    public void setTotalPaye(double totalPaye) {
        this.totalPaye = totalPaye; 
    }
    public void setResteAPayer(double resteAPayer) {
        this.resteAPayer = resteAPayer; 
    }
//----------------------------------------------------------------------------
    public void ajouterSeance(Seance s) {
        seances.add(s);
    }

    @Override
    public String toString() {
        return "Candidat{" +
                "CIN='" + cin + '\'' +
                ", Nom='" + nom + " " + prenom + '\'' +
                ", Catégorie Permis='" + categoriePermis + '\'' +
                ", Total Payé=" + totalPaye +
                ", Reste à payer=" + resteAPayer +
                '}';
    }






}

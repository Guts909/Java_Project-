package AutoEcole.Entities;

public class Moniteur {
    private String id;
    private String nom;
    private String specialite;

    // Constructeur
    public Moniteur(String id, String nom, String specialite) {
        this.id = id;
        this.nom = nom;
        this.specialite = specialite;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getSpecialite() {
        return specialite;
    }

    // Setters (optionnels si tu veux modifier après création)
    public void setId(String id) {
        this.id = id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setSpecialite(String specialite) {
        this.specialite = specialite;
    }

    @Override
    public String toString() {
        return "Moniteur{" +
                "id='" + id + '\'' +
                ", nom='" + nom + '\'' +
                ", spécialité='" + specialite + '\'' +
                '}';
    }
}

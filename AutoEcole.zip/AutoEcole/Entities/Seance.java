package AutoEcole.Entities;

import java.time.LocalDateTime;

public class Seance {
    private int numero;
    private LocalDateTime dateHeure;
    private Moniteur moniteur;
    private double prix;

    public Seance(int numero, LocalDateTime dateHeure, Moniteur moniteur, double prix) {
        this.numero = numero;
        this.dateHeure = dateHeure;
        this.moniteur = moniteur;
        this.prix = prix;
    }

    public int getNumero() {
        return numero;
    }

    public LocalDateTime getDateHeure() {
        return dateHeure;
    }

    public Moniteur getMoniteur() {
        return moniteur;
    }

    public double getPrix() {
        return prix;
    }

    public void setDateHeure(LocalDateTime dateHeure) {
        this.dateHeure = dateHeure;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public void setMoniteur(Moniteur moniteur) {
        this.moniteur = moniteur;
    }

    @Override
    public String toString() {
        return "Séance #" + numero + " | " + dateHeure + " | Moniteur: " +
               (moniteur != null ? moniteur.getNom() : "Non assigné") +
               " | Prix: " + prix + " TND";
    }
}

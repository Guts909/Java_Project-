package AutoEcole.Controller;

import java.util.ArrayList;

import AutoEcole.Entities.Moniteur;
import AutoEcole.Service.MoniteurService;

public class MoniteurController {
    private final MoniteurService service = new MoniteurService();

    public void ajouterMoniteur(Moniteur m) {
        service.ajouterMoniteur(m);
    }

    public void supprimerMoniteur(String nom) {
        service.supprimerMoniteur(nom);
    }

    public Moniteur rechercherMoniteur(String nom) {
        return service.rechercherMoniteur(nom);
    }

    public double calculerSalaire(Moniteur m) {
        return service.calculerSalaireMoniteur(m);
    }

    public ArrayList<Moniteur> getTous() {
        return service.getTous();
    }
    public void mettreAJourMoniteur(Moniteur m) {
    service.mettreAJourMoniteur(m);
}

}

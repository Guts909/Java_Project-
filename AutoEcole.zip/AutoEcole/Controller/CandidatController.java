package AutoEcole.Controller;

import AutoEcole.Service.CandidatService;
import AutoEcole.Entities.Candidat;

import java.util.ArrayList;

public class CandidatController {
    private final CandidatService service = new CandidatService();

    public void ajouterCandidat(Candidat c) {
        service.ajouterCandidat(c);
    }

    public void supprimerCandidat(String cin) {
        service.supprimerCandidat(cin);
    }

    public Candidat rechercherCandidat(String cin) {
        return service.rechercherCandidat(cin);
    }

    public ArrayList<Candidat> getTous() {
        return service.getTous();
    }

    public void afficherTous() {
        service.afficherTous();
    }

    
    public void mettreAJourCandidat(Candidat c) {
        service.mettreAJourCandidat(c);
    }
}

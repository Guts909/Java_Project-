package AutoEcole.Controller;

import AutoEcole.Service.SeanceService;
import AutoEcole.Entities.Seance;

import java.util.ArrayList;

public class SeanceController {
    private final SeanceService service = new SeanceService();

    public void ajouterSeance(Seance s) {
        service.ajouterSeance(s);
    }

    public void supprimerSeance(int numero) {
        service.supprimerSeance(numero);
    }

    public Seance rechercherSeance(int numero) {
        return service.rechercherSeance(numero);
    }

    public ArrayList<Seance> getToutes() {
        return service.getToutes();
    }

    public void afficherToutes() {
        service.afficherToutes();
    }

    // ✏️ Update method
    public void mettreAJourSeance(Seance s) {
        service.mettreAJourSeance(s);
    }
}

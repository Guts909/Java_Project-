package AutoEcole.Service;

import java.util.ArrayList;
import AutoEcole.Entities.Moniteur;
import AutoEcole.Repository.MoniteurRepository;

public class MoniteurService {
    private final MoniteurRepository repo = new MoniteurRepository();
    private ArrayList<Moniteur> moniteurs;

    public MoniteurService() {
        moniteurs = repo.loadAll();
    }

    // ➕ Add a monitor
    public void ajouterMoniteur(Moniteur m) {
        moniteurs.add(m);
        repo.saveAll(moniteurs);
    }

    // ❌ Remove a monitor by name
    public void supprimerMoniteur(String nom) {
        moniteurs.removeIf(m -> m.getNom().equalsIgnoreCase(nom));
        repo.saveAll(moniteurs);
    }

    // 🔍 Search for a monitor by name
    public Moniteur rechercherMoniteur(String nom) {
        for (Moniteur m : moniteurs) {
            if (m.getNom().equalsIgnoreCase(nom)) {
                return m;
            }
        }
        return null;
    }

    // 💰 Calculate salary for a monitor
    public double calculerSalaireMoniteur(Moniteur m) {
        return m.calculerSalaire();
    }

    // 📋 Get all monitors
    public ArrayList<Moniteur> getTous() {
        return moniteurs;
    }

    // ✏️ Update monitor attributes
    public void mettreAJourMoniteur(Moniteur updated) {
        for (Moniteur m : moniteurs) {
            if (m.getNom().equalsIgnoreCase(updated.getNom())) {
                // Update attributes
                m.setDisponible(updated.isDisponible());
                m.setSalaireHoraire(updated.getSalaireHoraire());
                m.ajouterHeures(updated.getHeuresTravaillees() - m.getHeuresTravaillees());

                // Save changes
                repo.saveAll(moniteurs);
                return;
            }
        }
        System.out.println("Moniteur introuvable !");
    }
}

package AutoEcole.Service;

import AutoEcole.Entities.Seance;
import AutoEcole.Repository.SeanceRepository;
import java.util.ArrayList;

public class SeanceService {
    private final SeanceRepository repo = new SeanceRepository();
    private ArrayList<Seance> seances;

    public SeanceService() {
        seances = repo.loadAll();
    }

    public void ajouterSeance(Seance s) {
        seances.add(s);
        repo.saveAll(seances);
    }

    public void supprimerSeance(int numero) {
        seances.removeIf(s -> s.getNumero() == numero);
        repo.saveAll(seances);
    }

    public ArrayList<Seance> getToutes() {
        return seances;
    }

    public Seance rechercherSeance(int numero) {
        for (Seance s : seances) {
            if (s.getNumero() == numero) {
                return s;
            }
        }
        return null;
    }

    public void afficherToutes() {
        if (seances.isEmpty()) {
            System.out.println("Aucune séance enregistrée.");
        } else {
            seances.forEach(System.out::println);
        }
    }

    public void mettreAJourSeance(Seance updated) {
        for (int i = 0; i < seances.size(); i++) {
            if (seances.get(i).getNumero() == updated.getNumero()) {
                seances.set(i, updated);
                repo.saveAll(seances);
                return;
            }
        }
        System.out.println("Séance introuvable !");
    }
}

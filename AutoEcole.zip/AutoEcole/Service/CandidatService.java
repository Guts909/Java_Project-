package AutoEcole.Service;

import java.util.ArrayList;
import AutoEcole.Entities.Candidat;
import AutoEcole.Repository.CandidatRepository;

public class CandidatService {

    private final CandidatRepository repo = new CandidatRepository();
    private ArrayList<Candidat> candidats;

    public CandidatService() {
        candidats = repo.loadAll();
    }

    // ➕ Add a candidate
    public void ajouterCandidat(Candidat c) {
        candidats.add(c);
        repo.saveAll(candidats);
    }

    // ❌ Remove a candidate by CIN
    public void supprimerCandidat(String cin) {
        candidats.removeIf(c -> c.getCin().equalsIgnoreCase(cin));
        repo.saveAll(candidats);
    }

    // 🔍 Search for a candidate by CIN
    public Candidat rechercherCandidat(String cin) {
        for (Candidat c : candidats) {
            if (c.getCin().equalsIgnoreCase(cin)) {
                return c;
            }
        }
        return null;
    }

    // 📋 Get all candidates
    public ArrayList<Candidat> getTous() {
        return candidats;
    }

    // 📢 Display all candidates
    public void afficherTous() {
        if (candidats.isEmpty()) {
            System.out.println("Aucun candidat enregistré.");
        } else {
            candidats.forEach(System.out::println);
        }
    }

    // ✏️ Update candidate attributes
    public void mettreAJourCandidat(Candidat updated) {
        for (Candidat c : candidats) {
            if (c.getCin().equalsIgnoreCase(updated.getCin())) {
                // Update attributes
                c.setTotalPaye(updated.getTotalPaye());
                c.setResteAPayer(updated.getResteAPayer());
                c.getSeances().clear();
                c.getSeances().addAll(updated.getSeances());

                // Save changes
                repo.saveAll(candidats);
                return;
            }
        }
        System.out.println("Candidat introuvable !");
    }
}

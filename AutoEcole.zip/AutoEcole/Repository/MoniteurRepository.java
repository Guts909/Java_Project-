package AutoEcole.Repository;

import AutoEcole.Entities.Moniteur;
import org.json.JSONObject;

import java.util.ArrayList;

public class MoniteurRepository {
    private final String filePath = "data/moniteurs.json";

    // Charger tous les moniteurs depuis le fichier JSON
    public ArrayList<Moniteur> loadAll() {
        return JsonManager.readList(filePath, obj -> {
            String id = obj.getString("id");
            String nom = obj.getString("nom");
            String specialite = obj.getString("specialite");

            Moniteur m = new Moniteur(id, nom, specialite);
            return m;
        });
    }

    // Sauvegarder tous les moniteurs dans le fichier JSON
    public void saveAll(ArrayList<Moniteur> moniteurs) {
        JsonManager.writeList(filePath, moniteurs, m -> {
            JSONObject obj = new JSONObject();
            obj.put("id", m.getId());
            obj.put("nom", m.getNom());
            obj.put("specialite", m.getSpecialite());
            return obj;
        });
    }
}

package AutoEcole.Repository;

import AutoEcole.Entities.Candidat;
import org.json.JSONObject;

import java.util.ArrayList;

public class CandidatRepository {
    private final String filePath = "data/candidats.json";

    // Charger tous les candidats depuis le fichier JSON
    public ArrayList<Candidat> loadAll() {
        return JsonManager.readList(filePath, obj -> {
            String cin = obj.getString("cin");
            String nom = obj.getString("nom");
            String prenom = obj.getString("prenom");
            String categoriePermis = obj.getString("categoriePermis");
            double totalPaye = obj.optDouble("totalPaye", 0);
            double resteAPayer = obj.optDouble("resteAPayer", 0);

            Candidat c = new Candidat(cin, nom, prenom, categoriePermis);
            c.setTotalPaye(totalPaye);
            c.setResteAPayer(resteAPayer);
            return c;
        });
    }

    // Sauvegarder tous les candidats dans le fichier JSON
    public void saveAll(ArrayList<Candidat> candidats) {
        JsonManager.writeList(filePath, candidats, c -> {
            JSONObject obj = new JSONObject();
            obj.put("cin", c.getCin());
            obj.put("nom", c.getNom());
            obj.put("prenom", c.getPrenom());
            obj.put("categoriePermis", c.getCategoriePermis());
            obj.put("totalPaye", c.getTotalPaye());
            obj.put("resteAPayer", c.getResteAPayer());
            return obj;
        });
    }
}

package AutoEcole.Repository;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Function;

public class JsonManager {

    // 🔹 Lire une liste depuis un fichier JSON
    public static <T> ArrayList<T> readList(String path, Function<JSONObject, T> mapper) {
        ArrayList<T> list = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            if (sb.length() > 0) {
                JSONArray arr = new JSONArray(sb.toString());
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject obj = arr.getJSONObject(i);
                    list.add(mapper.apply(obj)); // mapper transforme JSONObject → objet Java
                }
            }
        } catch (IOException e) {
            System.out.println("⚠️ Impossible de lire le fichier JSON : " + path);
        }
        return list;
    }

    // 🔹 Écrire une liste dans un fichier JSON
    public static <T> void writeList(String path, ArrayList<T> list, Function<T, JSONObject> mapper) {
        JSONArray arr = new JSONArray();
        for (T item : list) {
            arr.put(mapper.apply(item)); // mapper transforme objet Java → JSONObject
        }

        try (FileWriter writer = new FileWriter(path)) {
            writer.write(arr.toString(2)); // indentation pour lisibilité
        } catch (IOException e) {
            System.out.println("❌ Erreur d'écriture JSON : " + e.getMessage());
        }
    }
}

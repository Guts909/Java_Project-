package AutoEcole.Repository;

import AutoEcole.Entities.Seance;
import AutoEcole.Entities.Moniteur;
import org.json.JSONObject;

import java.util.ArrayList;

public class SeanceRepository {
    private final String filePath = "data/seances.json";

    public ArrayList<Seance> loadAll() {
        return JsonManager.readList(filePath, obj -> {
            int numero = obj.getInt("numero");
            String dateHeure = obj.getString("dateHeure");
            double prix = obj.getDouble("prix");

            // ⚠️ Moniteur simplifié (tu peux améliorer selon ton modèle)
            JSONObject moniteurJson = obj.optJSONObject("moniteur");
            Moniteur m = null;
            if (moniteurJson != null) {
                m = new Moniteur(moniteurJson.getString("id"), moniteurJson.getString("nom"), moniteurJson.getString("specialite"));
            }

            return new Seance(numero, java.time.LocalDateTime.parse(dateHeure), m, prix);
        });
    }

    public void saveAll(ArrayList<Seance> seances) {
        JsonManager.writeList(filePath, seances, s -> {
            JSONObject obj = new JSONObject();
            obj.put("numero", s.getNumero());
            obj.put("dateHeure", s.getDateHeure().toString());
            obj.put("prix", s.getPrix());

            if (s.getMoniteur() != null) {
                JSONObject moniteurJson = new JSONObject();
                moniteurJson.put("id", s.getMoniteur().getId());
                moniteurJson.put("nom", s.getMoniteur().getNom());
                moniteurJson.put("specialite", s.getMoniteur().getSpecialite());
                obj.put("moniteur", moniteurJson);
            }
            return obj;
        });
    }
}
